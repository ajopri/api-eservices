<?php echo e($slot); ?>

<?php /**PATH C:\Users\MCI-ACHMAD\Desktop\E-services\api\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>